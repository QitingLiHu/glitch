package com.chatbot.demo.controller;

public class OpcionSeleccionada {

	private String respuesta;

	public OpcionSeleccionada() {}
	
	public String getRespuesta() {
		return respuesta;
	}

	public void setRespuesta(String respuesta) {
		this.respuesta = respuesta;
	}
	
	
}
